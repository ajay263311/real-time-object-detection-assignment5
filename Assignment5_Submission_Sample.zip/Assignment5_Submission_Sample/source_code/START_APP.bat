@echo off
title Object Detection Project Setup
cd /d "%~dp0"
python --version
if errorlevel 1 (
  echo Python was not found. Install Python first.
  pause
  exit /b 1
)
python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo Package installation failed. This can happen on Windows ARM.
  pause
  exit /b 1
)
python -m streamlit run app.py
pause
