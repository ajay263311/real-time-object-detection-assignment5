import streamlit as st
from ultralytics import YOLO
from PIL import Image
import pandas as pd
from datetime import datetime

st.set_page_config(page_title="Object Detection & Logging", page_icon="🔎", layout="wide")
st.title("Real-Time Object Detection & Logging Platform")
st.write("Upload an image, detect objects with YOLO, review confidence scores, and export an event log.")

@st.cache_resource
def load_model():
    return YOLO("yolov8n.pt")

if "events" not in st.session_state:
    st.session_state.events = []

uploaded = st.file_uploader("Upload an image", type=["jpg", "jpeg", "png", "webp"])
if uploaded:
    image = Image.open(uploaded).convert("RGB")
    st.image(image, caption="Input image", use_container_width=True)
    if st.button("Detect Objects", type="primary"):
        try:
            result = load_model().predict(image, conf=0.25, verbose=False)[0]
            st.session_state.annotated = result.plot()[:, :, ::-1]
            found = []
            for box in result.boxes:
                class_id = int(box.cls[0].item())
                confidence = float(box.conf[0].item())
                found.append({"timestamp": datetime.now().isoformat(timespec="seconds"),
                              "image_name": uploaded.name,
                              "object_name": result.names.get(class_id, str(class_id)),
                              "confidence": round(confidence, 4)})
            st.session_state.events.extend(found)
            st.session_state.latest = found
            st.success(f"Detection finished: {len(found)} object(s) found.")
        except Exception as exc:
            st.error("The model could not run in this environment. Windows ARM package support can vary.")
            st.code(str(exc))

if "annotated" in st.session_state:
    st.subheader("Annotated detection output")
    st.image(st.session_state.annotated, use_container_width=True)
    if st.session_state.get("latest"):
        st.dataframe(pd.DataFrame(st.session_state.latest), use_container_width=True)
    else:
        st.info("No objects were detected above the confidence threshold.")

st.divider()
st.subheader("Event Log")
if st.session_state.events:
    log = pd.DataFrame(st.session_state.events)
    st.dataframe(log, use_container_width=True)
    st.download_button("Export event log as CSV", log.to_csv(index=False).encode("utf-8"),
                       "detection_events.csv", "text/csv")
else:
    st.info("No detections logged yet. Upload an image and click Detect Objects.")
st.caption("Academic starter project. Live webcam and persistent MySQL logging are extension tasks.")
