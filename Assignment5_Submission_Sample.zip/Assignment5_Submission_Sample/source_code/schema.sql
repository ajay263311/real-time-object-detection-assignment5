CREATE DATABASE IF NOT EXISTS object_detection_db;
USE object_detection_db;
CREATE TABLE IF NOT EXISTS detection_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    image_name VARCHAR(255),
    object_name VARCHAR(100) NOT NULL,
    confidence DECIMAL(6,4)
);
