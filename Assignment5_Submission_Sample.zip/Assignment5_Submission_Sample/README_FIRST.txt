ASSIGNMENT 5 — START HERE

This ZIP includes:
- source_code/app.py: Python/Streamlit app using YOLO for uploaded images
- source_code/requirements.txt: required packages
- source_code/schema.sql: starter MySQL schema
- source_code/START_APP.bat: Windows setup helper
- sample_demo/index.html: visual-only mock-up (not real AI detection)
- documentation/Project_Report.docx: editable project report
- documentation/MEDIUM_ARTICLE_DRAFT.md: article draft
- documentation/SUBMISSION_CHECKLIST.md: checklist

To try the Python app:
1. Open source_code folder.
2. Double-click START_APP.bat, or run commands in a terminal.
3. If package installation fails, save the error and ask for help. Windows ARM can have PyTorch/Ultralytics compatibility limits.

Important: This is a prepared starter/sample package, not a verified deployed system. The HTML preview is only a mock-up. Do not claim the app, database, GitHub, demo recording, or Medium article is completed unless you actually completed those steps.

Assignment form from the instructions: https://forms.gle/fUgKta3BSytbpGpv7
