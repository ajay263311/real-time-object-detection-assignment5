# Building an Object Detection and Logging Platform with Python and YOLO

## Introduction
Object detection identifies objects in images and locates them with bounding boxes. This project explores a web interface for image-based detection and event logging.

## Technology
The sample implementation uses Python, Streamlit, Ultralytics YOLO, Pillow, and pandas. A MySQL schema is included as a starting point for persistent event storage.

## Workflow
1. The user uploads an image.
2. YOLO predicts object classes and confidence scores.
3. The application displays an annotated image.
4. Detected objects are added to an event table.
5. The event history can be exported as CSV.

## Limitations and future improvements
This is a starter implementation and requires environment testing. Future improvements include live webcam input, persistent MySQL integration, and deployment. Compatibility with Windows ARM depends on available Python and PyTorch builds.

## Conclusion
The project provides a foundation for learning how computer vision can be integrated into a web interface with event logging.
