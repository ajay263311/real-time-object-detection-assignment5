# Submission checklist

- [ ] Add your name, roll number, class, and instructor to the report.
- [ ] Test the Python app if installation succeeds.
- [ ] Capture a genuine demo only after the app runs.
- [ ] Create a GitHub repository and upload source code if required.
- [ ] Publish the article only if required by your instructor.
- [ ] Submit using the instructor's specified Classroom/Form process.
- [ ] Form provided in the assignment: https://forms.gle/fUgKta3BSytbpGpv7

Do not mark steps complete unless you have actually done them.
